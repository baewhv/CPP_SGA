#include "../framework.h"
#include "Monster.h"

Monster::Monster(string name, int hp, int atk, int speed)
	: Creature(name, hp, atk, speed)
{
}
