#include "../framework.h"
#include "Player.h"

Player::Player(string name, int hp, int atk, int speed) : Creature(name, hp, atk, speed)
{

}
