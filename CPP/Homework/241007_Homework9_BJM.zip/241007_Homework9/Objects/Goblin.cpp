#include "../framework.h"
#include "Goblin.h"

Goblin::Goblin(int hp, int atk, int speed)
	: Monster("Goblin", hp, atk, speed)
{

}
