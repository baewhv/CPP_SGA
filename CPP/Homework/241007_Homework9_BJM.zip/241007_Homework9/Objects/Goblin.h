#pragma once
class Goblin : public Monster
{
public:
	Goblin(int hp, int atk, int speed);
};

